/**
 * 
 */
package stocks;

/**
 * @author asad
 *
 */
public class Stock {
	/** the stock symbol*/
	private String symbol;
	
	/** total number of shares of the stock*/
	private int totalShares;
	
	/** the total cost of this stock */
	private double totalCost;

	
	/**
	 * @param symbol
	 */
	public Stock (String symbol) {
		this.symbol = symbol;
		totalShares = 0;
		totalCost = 0.0;
	}
	
	/**
	 * @return symbol
	 */
	public String getSymbol() {
		return symbol;
	}


	/**
	 * @return totalShares
	 */
	public int getTotalShares() {
		return totalShares;
	}


	/**
	 * @return total cost
	 */
	public double getTotalCost() {
		return totalCost;
	}
	
	@Override
	public String toString() {
		return "Stock [symbol=" + symbol + ", totalShares=" + totalShares + ", totalCost=" + totalCost + "]";
	}
	
}
